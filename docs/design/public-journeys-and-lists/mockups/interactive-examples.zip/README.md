# IMSDA Events — design mockups

Extract this archive, then open index.html. The six prototype pages also open individually under prototype/; no server/build/network connection is needed for the local examples. Browser clipboard restrictions have a manual-copy fallback.

The seven-page PDF is IMSDA-design-ideas.pdf. The screenshots folder contains desktop/phone views plus task and interaction states. design-notes.md explains proposed behavior, fixture meanings, role boundaries and existing issue ownership.

All people, addresses, dates, records and amounts are synthetic. Local edits reset on reload. No real API, payment, registration, email, upload, deletion, publication or permission action is performed. Links copied by the editor use the reserved events.example.test domain. The gallery links to GitHub only if you choose them.

Fonts retain their SIL license in prototype/assets/FONT-LICENSE.txt.
