# IMSDA Events — role workspace design examples

Open role-design-samples.html in a browser, then choose one of the four independent sample workspaces. Each prototype also opens directly from prototype/attendee.html, director.html, coordinator.html or admin.html.

All names, records, dates and amounts are synthetic. These examples make no external API calls and change no real records, permissions, messages, payments or settings. Local edits last only until reload. Payment/help and platform review actions explain existing workflows rather than perform them.

The attendee’s direct-billing retreat and the director’s church-billed Camporee are distinct examples. Coordinator views preserve current available-club scope and view-only record behavior; Team approvals is a separate narrow existing workflow. Only the administrator uses platform navigation.

The design gallery is outside product navigation. A real user’s workspace switch would include only workspaces they already have permission to enter.

The comparison PDF, source-based role contract and design notes are included. Bundled Noto fonts retain their license in prototype/assets/.
